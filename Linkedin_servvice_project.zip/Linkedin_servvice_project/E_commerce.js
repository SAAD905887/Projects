const ICONS = {
  carrot: `<svg viewBox="0 0 100 100" fill="none"><path d="M50 90C40 70 38 45 42 28C44 20 56 20 58 28C62 45 60 70 50 90Z" fill="#C8704A"/><path d="M50 28C46 18 36 14 30 16C34 22 38 26 50 28Z" fill="#3D4F38"/><path d="M50 28C54 18 64 14 70 16C66 22 62 26 50 28Z" fill="#5C7355"/><path d="M50 28C48 16 42 10 36 10C39 17 43 22 50 28Z" fill="#8FA888"/><path d="M46 38L44 50M50 36L50 55M54 38L56 50" stroke="#A85B39" stroke-width="2" stroke-linecap="round"/></svg>`,
  tomato: `<svg viewBox="0 0 100 100" fill="none"><circle cx="50" cy="58" r="32" fill="#C8704A"/><circle cx="38" cy="48" r="9" fill="#D88A66" opacity=".5"/><path d="M50 26C44 18 34 16 28 20C34 24 40 26 50 26Z" fill="#5C7355"/><path d="M50 26C56 18 66 16 72 20C66 24 60 26 50 26Z" fill="#3D4F38"/><path d="M50 26L50 14" stroke="#5C7355" stroke-width="3" stroke-linecap="round"/></svg>`,
  banana: `<svg viewBox="0 0 100 100" fill="none"><path d="M22 30C20 50 28 72 50 82C58 85 62 78 56 74C40 66 32 50 34 32C35 24 24 22 22 30Z" fill="#E8D27A"/><path d="M50 82C58 85 65 80 64 73" stroke="#A85B39" stroke-width="3" stroke-linecap="round" fill="none"/><path d="M22 30C21 26 24 20 30 20" stroke="#5C7355" stroke-width="3" stroke-linecap="round" fill="none"/></svg>`,
  orange: `<svg viewBox="0 0 100 100" fill="none"><circle cx="50" cy="55" r="32" fill="#C8704A"/><circle cx="50" cy="55" r="32" fill="none" stroke="#A85B39" stroke-width="1.5" opacity=".4"/><path d="M50 23C46 16 38 14 33 17" stroke="#5C7355" stroke-width="3" stroke-linecap="round" fill="none"/><circle cx="50" cy="20" r="4" fill="#5C7355"/></svg>`,
  lettuce: `<svg viewBox="0 0 100 100" fill="none"><path d="M50 85C30 85 16 70 18 50C20 32 35 20 50 22C65 20 80 32 82 50C84 70 70 85 50 85Z" fill="#8FA888"/><path d="M50 85C36 85 26 73 28 56C30 40 40 30 50 32" stroke="#5C7355" stroke-width="2" fill="none" opacity=".6"/><path d="M50 85C64 85 74 73 72 56C70 40 60 30 50 32" stroke="#3D4F38" stroke-width="2" fill="none" opacity=".6"/></svg>`,
  riceBag: `<svg viewBox="0 0 100 100" fill="none"><path d="M26 30H74L70 88C70 91 67 94 64 94H36C33 94 30 91 30 88Z" fill="#F7F4EC" stroke="#1F2B1E" stroke-width="2"/><path d="M26 30C26 24 32 18 50 18C68 18 74 24 74 30" fill="none" stroke="#1F2B1E" stroke-width="2"/><rect x="34" y="44" width="32" height="22" rx="2" fill="#8FA888"/><text x="50" y="60" font-size="11" fill="#1F2B1E" text-anchor="middle" font-family="sans-serif" font-weight="700">RICE</text></svg>`,
  pasta: `<svg viewBox="0 0 100 100" fill="none"><rect x="28" y="16" width="44" height="72" rx="4" fill="#F7F4EC" stroke="#1F2B1E" stroke-width="2"/><rect x="34" y="24" width="32" height="20" fill="#C8704A"/><path d="M38 56V80M44 56V80M50 56V80M56 56V80M62 56V80" stroke="#E8D27A" stroke-width="3" stroke-linecap="round"/></svg>`,
  oilBottle: `<svg viewBox="0 0 100 100" fill="none"><path d="M40 30H60V40L66 48V86C66 89 63 92 60 92H40C37 92 34 89 34 86V48L40 40Z" fill="#C8704A" opacity=".85"/><rect x="42" y="16" width="16" height="16" rx="2" fill="#5C7355"/><rect x="40" y="54" width="20" height="26" rx="2" fill="#F7F4EC" opacity=".9"/></svg>`,
  honeyJar: `<svg viewBox="0 0 100 100" fill="none"><rect x="30" y="38" width="40" height="48" rx="6" fill="#E8D27A"/><rect x="34" y="22" width="32" height="18" rx="4" fill="#3D4F38"/><rect x="34" y="22" width="32" height="6" fill="#5C7355"/><circle cx="50" cy="62" r="10" fill="#C8704A" opacity=".5"/></svg>`,
  milk: `<svg viewBox="0 0 100 100" fill="none"><path d="M38 18H62L66 32L60 40V86C60 89 57 92 54 92H46C43 92 40 89 40 86V40L34 32Z" fill="#F7F4EC" stroke="#1F2B1E" stroke-width="2"/><rect x="40" y="50" width="20" height="16" fill="#8FA888"/></svg>`,
  cheese: `<svg viewBox="0 0 100 100" fill="none"><path d="M14 70L50 24L86 70Z" fill="#E8D27A"/><circle cx="40" cy="58" r="4" fill="#C8704A" opacity=".5"/><circle cx="58" cy="62" r="3" fill="#C8704A" opacity=".5"/><circle cx="50" cy="48" r="3.5" fill="#C8704A" opacity=".5"/></svg>`,
  eggs: `<svg viewBox="0 0 100 100" fill="none"><rect x="14" y="40" width="72" height="40" rx="6" fill="#A85B39"/><ellipse cx="32" cy="50" rx="11" ry="14" fill="#F7F4EC"/><ellipse cx="68" cy="50" rx="11" ry="14" fill="#F7F4EC"/><ellipse cx="50" cy="54" rx="11" ry="14" fill="#F7F4EC"/></svg>`,
  bread: `<svg viewBox="0 0 100 100" fill="none"><path d="M16 60C16 38 30 24 50 24C70 24 84 38 84 60C84 64 81 67 77 67H23C19 67 16 64 16 60Z" fill="#E8D27A"/><rect x="16" y="60" width="68" height="16" rx="4" fill="#C8704A"/><path d="M34 38C38 32 44 30 50 30M50 30C56 30 62 32 66 38" stroke="#A85B39" stroke-width="2" fill="none"/></svg>`,
  tshirt: `<svg viewBox="0 0 100 100" fill="none"><path d="M36 18L50 26L64 18L82 28L74 44L66 38V86H34V38L26 44L18 28Z" fill="#5C7355"/><path d="M40 18C42 24 46 27 50 27C54 27 58 24 60 18" stroke="#3D4F38" stroke-width="2" fill="none"/></svg>`,
  tshirtClay: `<svg viewBox="0 0 100 100" fill="none"><path d="M36 18L50 26L64 18L82 28L74 44L66 38V86H34V38L26 44L18 28Z" fill="#C8704A"/><path d="M40 18C42 24 46 27 50 27C54 27 58 24 60 18" stroke="#A85B39" stroke-width="2" fill="none"/></svg>`,
  jeans: `<svg viewBox="0 0 100 100" fill="none"><path d="M32 14H68L70 50L64 88H54L50 56L46 88H36L30 50Z" fill="#3D4F38"/><path d="M32 14H68" stroke="#1F2B1E" stroke-width="3"/><path d="M44 14L40 88M56 14L60 88" stroke="#8FA888" stroke-width="1" opacity=".4"/></svg>`,
  sneaker: `<svg viewBox="0 0 100 100" fill="none"><path d="M10 68C10 62 16 58 24 58C30 58 34 54 40 50C48 44 58 42 68 44C78 46 88 52 90 62C91 68 86 72 78 72H14C11 72 10 70 10 68Z" fill="#F7F4EC" stroke="#1F2B1E" stroke-width="2"/><path d="M24 58C30 58 34 54 40 50C48 44 58 42 68 44" stroke="#C8704A" stroke-width="3" fill="none"/><rect x="14" y="68" width="76" height="8" rx="2" fill="#1F2B1E"/></svg>`,
  cap: `<svg viewBox="0 0 100 100" fill="none"><path d="M50 26C32 26 18 38 16 54H84C82 38 68 26 50 26Z" fill="#5C7355"/><path d="M84 54C92 54 96 58 96 62C96 65 92 66 86 64L80 54Z" fill="#3D4F38"/><circle cx="50" cy="26" r="5" fill="#3D4F38"/></svg>`,
  dress: `<svg viewBox="0 0 100 100" fill="none"><path d="M40 16H60L66 30L58 36L66 88H34L42 36L34 30Z" fill="#C8704A"/><path d="M44 16C45 22 47 25 50 25C53 25 55 22 56 16" stroke="#A85B39" stroke-width="2" fill="none"/></svg>`,
};

const PRODUCTS = [
  { id:1, name:"Fresh Carrots (1kg)", meta:"Local farms · Crisp & sweet", price:35, was:null, cat:"produce", icon:"carrot" },
  { id:2, name:"Vine Tomatoes (1kg)", meta:"Ripened on the vine", price:42, was:48, cat:"produce", icon:"tomato" },
  { id:3, name:"Bananas (1kg)", meta:"Sourced daily", price:28, was:null, cat:"produce", icon:"banana" },
  { id:4, name:"Navel Oranges (1kg)", meta:"Sweet & seedless", price:30, was:null, cat:"produce", icon:"orange" },
  { id:5, name:"Romaine Lettuce", meta:"Crisp leaves · Per head", price:18, was:null, cat:"produce", icon:"lettuce" },
  { id:6, name:"Egyptian Rice (5kg)", meta:"Pantry staple", price:240, was:265, cat:"pantry", icon:"riceBag" },
  { id:7, name:"Penne Pasta (500g)", meta:"Durum wheat", price:48, was:null, cat:"pantry", icon:"pasta" },
  { id:8, name:"Sunflower Oil (1.5L)", meta:"Cold pressed", price:165, was:null, cat:"pantry", icon:"oilBottle" },
  { id:9, name:"Pure Honey (500g)", meta:"Unfiltered, local hives", price:210, was:240, cat:"pantry", icon:"honeyJar" },
  { id:10, name:"Fresh Milk (1L)", meta:"Pasteurized · Full fat", price:38, was:null, cat:"dairy", icon:"milk" },
  { id:11, name:"Halloumi Cheese (250g)", meta:"Grill-ready", price:95, was:null, cat:"dairy", icon:"cheese" },
  { id:12, name:"Farm Eggs (12-pack)", meta:"Free range", price:75, was:85, cat:"dairy", icon:"eggs" },
  { id:13, name:"Baladi Bread (5 loaves)", meta:"Baked fresh daily", price:15, was:null, cat:"dairy", icon:"bread" },
  { id:14, name:"Classic Cotton Tee", meta:"Unisex · Sage green", price:280, was:340, cat:"clothing", icon:"tshirt" },
  { id:15, name:"Classic Cotton Tee", meta:"Unisex · Terracotta", price:280, was:null, cat:"clothing", icon:"tshirtClay" },
  { id:16, name:"Straight Fit Jeans", meta:"Mid-wash denim", price:650, was:750, cat:"clothing", icon:"jeans" },
  { id:17, name:"Everyday Sneakers", meta:"Lightweight · All sizes", price:780, was:null, cat:"clothing", icon:"sneaker" },
  { id:18, name:"Canvas Cap", meta:"Adjustable strap", price:190, was:null, cat:"clothing", icon:"cap" },
  { id:19, name:"Summer Midi Dress", meta:"Breathable linen blend", price:520, was:580, cat:"clothing", icon:"dress" },
];

function formatEGP(amount){
  return `EGP ${amount.toLocaleString('en-US')}`;
}

let cart = [];

const grid = document.getElementById('productGrid');
const filtersEl = document.getElementById('filters');
const cartDrawer = document.getElementById('cartDrawer');
const overlay = document.getElementById('overlay');
const cartItemsEl = document.getElementById('cartItems');
const cartEmptyEl = document.getElementById('cartEmpty');
const cartTotalEl = document.getElementById('cartTotal');
const cartCountEl = document.getElementById('cartCount');
const cartFillEl = document.getElementById('cartFill');
const toastEl = document.getElementById('toast');

const CATEGORY_LABELS = {
  produce: "Produce",
  pantry: "Pantry",
  dairy: "Dairy & Bakery",
  clothing: "Clothing",
};

function renderProducts(filter = 'all'){
  grid.innerHTML = PRODUCTS.map((p, i) => `
    <article class="card ${filter !== 'all' && p.cat !== filter ? 'hide' : ''}" style="animation-delay:${i * 0.04}s">
      <div class="card-media">
        <div class="icon">${ICONS[p.icon]}</div>
        <span class="card-tag">${CATEGORY_LABELS[p.cat]}</span>
        <button class="card-add" data-id="${p.id}" aria-label="Add ${p.name} to basket">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
        </button>
      </div>
      <h3 class="card-name">${p.name}</h3>
      <p class="card-meta">${p.meta}</p>
      <div class="card-bottom">
        <span class="card-price">${p.was ? `<span class="was">${formatEGP(p.was)}</span>` : ''}${formatEGP(p.price)}</span>
      </div>
    </article>
  `).join('');
}
renderProducts();

filtersEl.addEventListener('click', (e) => {
  const btn = e.target.closest('.filter');
  if (!btn) return;
  filtersEl.querySelectorAll('.filter').forEach(f => f.classList.remove('active'));
  btn.classList.add('active');
  renderProducts(btn.dataset.filter);
});

function addToCart(id){
  const existing = cart.find(c => c.id === id);
  if (existing) existing.qty++;
  else cart.push({ id, qty: 1 });
  updateCartUI();
}

function changeQty(id, delta){
  const item = cart.find(c => c.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(c => c.id !== id);
  updateCartUI();
}

function removeFromCart(id){
  cart = cart.filter(c => c.id !== id);
  updateCartUI();
}

function cartCount(){
  return cart.reduce((sum, c) => sum + c.qty, 0);
}

function cartTotal(){
  return cart.reduce((sum, c) => {
    const p = PRODUCTS.find(p => p.id === c.id);
    return sum + (p ? p.price * c.qty : 0);
  }, 0);
}

function updateCartUI(){
  const count = cartCount();
  cartCountEl.textContent = count;
  cartCountEl.classList.add('bump');
  setTimeout(() => cartCountEl.classList.remove('bump'), 300);

  const fillPct = Math.min(count / 8, 1) * 100;
  cartFillEl.style.height = count > 0 ? `${Math.max(fillPct, 18)}%` : '0%';

  cartTotalEl.textContent = formatEGP(cartTotal());

  if (cart.length === 0){
    cartEmptyEl.classList.remove('hide');
    cartItemsEl.innerHTML = '';
    return;
  }
  cartEmptyEl.classList.add('hide');

  cartItemsEl.innerHTML = cart.map(c => {
    const p = PRODUCTS.find(p => p.id === c.id);
    if (!p) return '';
    return `
      <div class="cart-item">
        <div class="cart-item-media">${ICONS[p.icon]}</div>
        <div>
          <p class="cart-item-name">${p.name}</p>
          <p class="cart-item-price">${formatEGP(p.price)} each</p>
          <div class="qty-row">
            <button class="qty-btn" data-action="dec" data-id="${p.id}" aria-label="Decrease quantity">−</button>
            <span class="qty-val">${c.qty}</span>
            <button class="qty-btn" data-action="inc" data-id="${p.id}" aria-label="Increase quantity">+</button>
          </div>
        </div>
        <button class="remove-btn" data-action="remove" data-id="${p.id}">Remove</button>
      </div>
    `;
  }).join('');
}

grid.addEventListener('click', (e) => {
  const btn = e.target.closest('.card-add');
  if (!btn) return;
  const id = Number(btn.dataset.id);
  const product = PRODUCTS.find(p => p.id === id);
  addToCart(id);
  btn.classList.add('added');
  setTimeout(() => btn.classList.remove('added'), 600);
  showToast(`${product.name} added to basket`);
});

cartItemsEl.addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = Number(btn.dataset.id);
  const action = btn.dataset.action;
  if (action === 'inc') changeQty(id, 1);
  if (action === 'dec') changeQty(id, -1);
  if (action === 'remove') removeFromCart(id);
});

function openCart(){
  cartDrawer.classList.add('open');
  overlay.classList.add('show');
  document.body.style.overflow = 'hidden';
}
function closeCart(){
  cartDrawer.classList.remove('open');
  overlay.classList.remove('show');
  document.body.style.overflow = '';
}
document.getElementById('cartBtn').addEventListener('click', openCart);
document.getElementById('closeCart').addEventListener('click', closeCart);
overlay.addEventListener('click', closeCart);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeCart();
});

document.getElementById('checkoutBtn').addEventListener('click', () => {
  if (cart.length === 0){
    showToast("Your basket is empty");
    return;
  }
  showToast(`Order placed — ${formatEGP(cartTotal())} 🌿`);
  cart = [];
  updateCartUI();
  setTimeout(closeCart, 900);
});

document.getElementById('newsletterForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const msg = document.getElementById('newsletterMsg');
  msg.textContent = "You're on the list — welcome aboard 🌿";
  msg.classList.add('show');
  e.target.reset();
});

let toastTimer;
function showToast(text){
  clearTimeout(toastTimer);
  toastEl.textContent = text;
  toastEl.classList.add('show');
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2200);
}

updateCartUI();
